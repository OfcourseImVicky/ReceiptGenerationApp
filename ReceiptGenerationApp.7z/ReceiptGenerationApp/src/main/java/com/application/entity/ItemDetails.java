package com.application.entity;

import org.springframework.stereotype.Component;

/**
 * @author Vignesh
 * @since 20.08 
 * ItemDetails is a pojo
 */
@Component
public class ItemDetails {
	private String itemName;
	private int quantity;
	private double originalPrice;
	private double finalPrice;
	private double discountPercent;
	private double discountPrice;
	private boolean isClearanceItem;

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getOriginalPrice() {
		return originalPrice;
	}

	public void setOriginalPrice(double originalPrice) {
		this.originalPrice = originalPrice;
	}

	public double getFinalPrice() {
		return finalPrice;
	}

	public void setFinalPrice(double finalPrice) {
		this.finalPrice = finalPrice;
	}

	public double getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(double discountPercent) {
		this.discountPercent = discountPercent;
	}

	public double getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(double discountPrice) {
		this.discountPrice = discountPrice;
	}

	public boolean isClearanceItem() {
		return isClearanceItem;
	}

	public void setIsClearanceItem(boolean isClearanceItem) {
		this.isClearanceItem = isClearanceItem;
	}

	@Override
	public String toString() {
		return "ItemDetails [itemName=" + itemName + ", quantity=" + quantity + ", originalPrice=" + originalPrice
				+ ", finalPrice=" + finalPrice + ", discountPercent=" + discountPercent + ", discountPrice="
				+ discountPrice + ", isClearanceItem=" + isClearanceItem + "]";
	}

}
