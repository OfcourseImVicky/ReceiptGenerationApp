package com.application;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.application.entity.ItemDetails;

/**
 * @author Vignesh
 * @since 20.08 
 * TaxCalculationReceiptApplication is the PILOT for the Receipt Generation Application
 */
@SpringBootApplication
public class ReceiptGenerationApplication {
	/** ROUNDOFF */
	private static final double ROUNDOFF = 0.01d;
	/** ENTRY_MESSAGE */
	private static final String ENTRY_MESSAGE = "Enter the number of Items";
	/** ITEM_REQUIREMENT */
	private static final String ITEM_REQUIREMENT = "Give Details of item";
	/** CLEARANCE */
	private static final String CLEARANCE = "clearance";
	/** BOTTLE */
	private static final String BOTTLE = "bottle";
	/** BOX */
	private static final String BOX = "box";
	/** BOOK */
	private static final String BOOK = "book";
	/** CHOCOLATE */
	private static final String CHOCOLATE = "chocolate";
	/** BOOK */
	private static final String PERFUME = "perfume";
	/** WINE */
	private static final String WINE = "wine";
	/** EMPTY */
	private static final String EMPTY = " ";
	/** AT */
	private static final String AT = "at";
	/** of */
	private static final String OF = "of";
	/** TOTAL */
	private static final String TOTAL = "Total:";
	/** DRESS */
	private static final String DRESS = "dress";
	/** SHIRT */
	private static final String SHIRT = "shirt";
	/** YOU_SAVED */
	private static final String YOU_SAVED = "You Saved:";
	/** CONSTANT_ZERO */
	private static final int CONSTANT_ZERO = 0;
	/** CONSTANT_ONE */
	private static final int CONSTANT_ONE = 1;
	/** CONSTANT_TWO */
	private static final int CONSTANT_TWO = 2;
	/** CONSTANT_THREE */
	private static final int CONSTANT_THREE = 3;
	/** CONSTANT_FIVE */
	private static final int CONSTANT_FIVE = 5;
	/** CONSTANT_TWENTY */
	private static final int CONSTANT_TWENTY = 20;
	/** CONSTANT_HUNDRED */
	private static final int CONSTANT_HUNDRED = 100;

	/**
	 * main method gets triggered first
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(ReceiptGenerationApplication.class, args);
		List<String> inputList = new ArrayList<>();
		printLog(ENTRY_MESSAGE);
		Scanner scannedInput = new Scanner(System.in);
		int itemQuantity = Integer.parseInt(scannedInput.next());
		for (int iterator = CONSTANT_ONE; iterator <= itemQuantity; iterator++) {
			printLog(ITEM_REQUIREMENT + EMPTY + iterator);
			String itemData = new Scanner(System.in).nextLine();
			inputList.add(itemData);
		}
		generateReceipt(inputList);
	}

	/**
	 * generateReceipt generates the receipt
	 * 
	 * @param inputList
	 */
	protected static void generateReceipt(List<String> inputList) {
		List<ItemDetails> itemDetailsList = new ArrayList<>();
		List<String[]> inputDetailedList = inputList.stream().map(item -> item.split(EMPTY))
				.collect(Collectors.toList());
		for (String[] stringArray : inputDetailedList) {
			ItemDetails item = new ItemDetails();
			item.setQuantity(Integer.parseInt(stringArray[CONSTANT_ZERO]));
			item.setOriginalPrice(Double.parseDouble(stringArray[stringArray.length - CONSTANT_ONE]));
			item.setIsClearanceItem(false);
			if (stringArray[CONSTANT_ONE].startsWith(CLEARANCE)) {
				item.setIsClearanceItem(true);
				item.setItemName(stringArray[CONSTANT_ONE] + EMPTY + stringArray[CONSTANT_TWO]);
			} else if (stringArray[CONSTANT_ONE].startsWith(BOTTLE) || stringArray[CONSTANT_ONE].startsWith(BOX)) {
				item.setItemName(stringArray[CONSTANT_ONE] + EMPTY + stringArray[CONSTANT_TWO] + EMPTY
						+ stringArray[CONSTANT_THREE]);
			} else {
				item.setItemName(stringArray[CONSTANT_ONE]);
			}
			applyDiscount(item, itemDetailsList);
		}
		printReceipt(itemDetailsList);
	}

	/**
	 * applyDiscount calculates discounts for the items and applies accordingly
	 * 
	 * @param item
	 * @param itemDetailsList
	 */
	private static void applyDiscount(ItemDetails item, List<ItemDetails> itemDetailsList) {
		switch (item.getItemName()) {
		case BOOK:
		case CHOCOLATE:
		case CLEARANCE + EMPTY + CHOCOLATE:
		case BOX + OF + CHOCOLATE:
		case BOTTLE + OF + PERFUME:
		case BOTTLE + OF + WINE:
			item.setDiscountPercent(CONSTANT_FIVE);
			break;
		case DRESS:
		case SHIRT:
			item.setDiscountPercent(CONSTANT_TWENTY);
		default:
			item.setDiscountPercent(CONSTANT_THREE);
			break;
		}
		if (item.isClearanceItem()) {
			item.setDiscountPercent(item.getDiscountPercent() + CONSTANT_TWENTY);
		}
		item.setDiscountPrice(item.getOriginalPrice() * item.getDiscountPercent() / CONSTANT_HUNDRED);
		item.setFinalPrice(item.getOriginalPrice() - item.getDiscountPrice());
		itemDetailsList.add(item);
	}

	/**
	 * printReceipt prints the output Receipt
	 * 
	 * @param itemDetailsList
	 */
	private static void printReceipt(List<ItemDetails> itemDetailsList) {
		itemDetailsList.forEach(item -> {
			printLog(item.getQuantity() + EMPTY + item.getItemName() + EMPTY + AT + EMPTY
					+ roundOffPrice(item.getFinalPrice()));
		});
		printLog(TOTAL + EMPTY
				+ roundOffPrice(itemDetailsList.stream().mapToDouble(item -> item.getFinalPrice()).sum()));
		printLog(YOU_SAVED + EMPTY
				+ roundOffPrice(itemDetailsList.stream().mapToDouble(item -> item.getDiscountPrice()).sum()));
	}

	/**
	 * roundOffPrice roundsOff the price amount
	 * 
	 * @param amount
	 * @return rounded price amount
	 */
	private static double roundOffPrice(double amount) {
		return (double) Math.ceil(amount / ROUNDOFF) * ROUNDOFF;
	}

	/**
	 * printLog is for logging
	 * 
	 * @param log
	 */
	static void printLog(String log) {
		System.out.println(log);
	}
}
