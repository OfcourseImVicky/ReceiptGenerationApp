package com.application;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@EnableAutoConfiguration
class ReceiptGenerationApplicationTests extends ReceiptGenerationApplication {

	/**
	 * testCaseOne tests generateReceipt method
	 */
	@Test
	void testCaseOne() {
		List<String> argListOne = new ArrayList<>();
		argListOne.add("1 book at 14.49");
		argListOne.add("1 shirt at 19.99");
		argListOne.add("1 chocolate bar at 1.00");
		argListOne.add("1 clearance chocolate bar at 2.00");
		generateReceipt(argListOne);
	}
	/**
	 * testCaseTwo tests generateReceipt method
	 */
	@Test
	void testCaseTwo() {
		List<String> argListTwo = new ArrayList<>();
		argListTwo.add("1 bottle of perfume at 27.99");
		argListTwo.add("1 bottle of wine at 18.99");
		argListTwo.add("1 dress at 9.75");
		argListTwo.add("1 box of chocolates at 11.25");
		generateReceipt(argListTwo);
	}

}
